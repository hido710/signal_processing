% close all;
clear all;
% clc;

%% STFT
% winL = 512;
% nfft = winL;
% nol = fix(3*winL/4);
% nshift = winL-nol;

winL = 1024;
nfft = winL;
nol = fix(winL/2);
nshift = winL-nol;


%% Data load & Setting
[x, Fs] = audioread(['mixture_2x8_RT60_0_SNR_0/x_2x8.wav']);
%[n, ~] = audioread(['mixture_2x8_RT60_0_SNR_0/x_2x8.wav']);
[n, ~] = audioread(['mixture_2x8_RT60_0_SNR_0/s_2x8_source_2.wav']);
load('mixture_2x8_RT60_0_SNR_0/location_sensor')
load('mixture_2x8_RT60_0_SNR_0/location_source')

[nsamples, nch] = size(x);

%% STFT batch
X = STFT_batch(x,winL,nfft,nshift); %X [channels x nhfft x frames]
N = STFT_batch(n,winL,nfft,nshift); %X [channels x nhfft x frames]


%% Process

% Check Sample delay
c = 343.3;
sampleDelay = zeros(nch,1);
for sensorindex = 1 : nch
    sampleDelay(sensorindex) = norm(locationSource{1} - locationSensor{sensorindex}, 2)/c*Fs;
end


% MVDR
Y = MPDR_batch_v01(X, N, sampleDelay,c,Fs);



%% ISTFT batch
y = ISTFT_batch(Y,winL,nshift,nsamples);


%% Figure
plotsensorIndex = 1;
color_min = -80;
color_max = 20;
figure;
imagesc(10*log10(abs(squeeze(X(plotsensorIndex,:,:))).^2))
caxis([color_min color_max])
title(['X (Mixed signal)'])
xlabel('time bin')
ylabel('freq bin')
axis xy
colormap jet;
colorbar

figure;
imagesc(10*log10(abs(squeeze(Y)).^2))
caxis([color_min color_max])
% title(['SHat (Beamformer batch output) diagLoad ' num2str(diagLambda)])
xlabel('time bin')
ylabel('freq bin')
axis xy
colormap jet;
hold off
colorbar




