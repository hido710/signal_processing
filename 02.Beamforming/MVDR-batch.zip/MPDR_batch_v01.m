%%
%% ======================================================================
%% MVDR_NEAR_FIELD 
%%
%%  Perforem MVDR assumption in far field model
%%
%% Copyright (c) 2016 Sogang University Intelligence Information Processing Laboratories.
%% All rights reserved.
%% Written by Jiwon Cho on June/9/2016
%% ======================================================================

function [Y] = MPDR_batch_v01(X_input, N_input, sampleDelay,c,Fs)

diagLambda = 10^(-3);

[nch, nfreq, nFrame] = size(X_input);

X = zeros(nFrame, nfreq, nch);
N = zeros(nFrame, nfreq, nch);

for ch = 1:nch
    for t_idx = 1:nFrame
        for f_idx = 1:nfreq
           X(t_idx,f_idx,ch) = X_input(ch,f_idx,t_idx);
           N(t_idx,f_idx,ch) = N_input(ch,f_idx,t_idx);
        end
    end
end



w = zeros(nch , nfreq);
Y = zeros(1,nfreq,nFrame);
steer_vec = zeros(nch,1);

nfft = (nfreq-1)*2;
lambdaDiag = diagLambda*eye(nch);

Ntemp = shiftdim(N,1); % [ freq mic frame ]
Nmean = sum(Ntemp,3) / nFrame; % [ freq mic ]
Nbias = Ntemp - repmat(Nmean, [1, 1, nFrame]); % [freq mic frame ]
%Nbias = Ntemp;
Nbias = shiftdim(Nbias,1); %[ mic frame freq ]
%Nbias = shiftdim(N,2);


% Calcuating MVDR beamformer for each frequency band
%--------------------------------------------------------------------------
for f_idx = 1 : nfreq  % index 1 = dc , index nfreq -1
        
    Rn = Nbias(:,:,f_idx) * Nbias(:,:,f_idx)'; % [ mic mic ]
    Rn = Rn ./ nFrame;
    for ch = 1:nch
        Rn(ch,ch) = abs(Rn(ch,ch));
    end    
    
    for ch = 1:nch
        steer_vec(ch) = exp(-1j*2*pi*(f_idx-1)/nfft*sampleDelay(ch));
    end
    steer_vec = steer_vec./(sampleDelay*c/Fs);
    
    Rn = Rn + lambdaDiag;
    wtemp = Rn\steer_vec / (steer_vec'* (Rn \ steer_vec));
    w(:,f_idx) = wtemp;
end

Xtemp = shiftdim(X,1); % [freq nmic frame]
wtemp = shiftdim(w,1); % [freq nmic]

for t_idx = 1 : nFrame
    Y_temp = Xtemp(:,:,t_idx).* conj(wtemp);
    Y(1,:,t_idx) = sum(Y_temp,2);
end








